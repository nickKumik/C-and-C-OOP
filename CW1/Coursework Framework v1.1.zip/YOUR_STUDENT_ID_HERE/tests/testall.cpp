


/*
  +---------------------------------------+
  | BETH YW? WELSH GOVERNMENT DATA PARSER |
  +---------------------------------------+

  AUTHOR: Dr Martin Porcheron

  Catch2 test script — https://github.com/catchorg/Catch2
  Catch2 is licensed under the BOOST license.
 */

#include "test1.cpp"
#include "test2.cpp"
#include "test3.cpp"
#include "test4.cpp"
#include "test5.cpp"
#include "test6.cpp"
#include "test7.cpp"
#include "test8.cpp"
#include "test9.cpp"
#include "test10.cpp"
#include "test11.cpp"
#include "test12.cpp"
