#define CATCH_CONFIG_MAIN 
#include "lib_catch.hpp"
